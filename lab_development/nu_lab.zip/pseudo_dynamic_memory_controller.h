#pragma once
#include <stdlib.h>
#include <iostream>

/* TO DO
* Create multi-type PseudoDynamicMemoryController
*/ 
#define MEMORY_TYPE float

class PseudoDynamicMemoryController {
public:
	PseudoDynamicMemoryController();
	int initilizeMemory(int requiredMemorySize);
	MEMORY_TYPE* holdMemory(int quantity);
	//~PseudoDynamicMemoryController();	
	//void releaseMemory();
	int loadFile(char* readingFileName, int columnsTotal, int stringsTotal);
	int loadFile(char* readingFileName, int columnsTotal, 
		int stringsTotal, MEMORY_TYPE* memoryPointer);
	int printMemoryContent(int startElementNumber, int endElementNumber, int stringLength);
	int printMemoryContent(MEMORY_TYPE* pointer, int quantity, int stringLength);
	inline MEMORY_TYPE* getMemoryPoolPointer() { return memoryPoolPointer; };
private:
	//int memoryPoolSizeInBytes;
	int memoryLeft;
	int shift;
	MEMORY_TYPE* memoryPoolPointer;
};


#include "slae.h"
/*
SLAESolver::SLAESolver(int requestedMemorySize) {
	memoryController = &PseudoDynamicMemoryController(requestedMemorySize);
};
*/



DATA_TYPE computeDi(DATA_TYPE* pAal, DATA_TYPE* pD, DATA_TYPE* pL, 
	int i, int lowBandWidth) { // i is the index of the calculated element of the D

	DATA_TYPE sum = 0;
	DATA_TYPE* pLi = &pAal[i * lowBandWidth + lowBandWidth - i];
	DATA_TYPE Lij = 0; // temp variable to prevent repeated requests to the member

	for (int j = 1; j < i + 1; j++) {
		Lij = *pLi;
		sum += ((*pD) * Lij * Lij);
		pLi++;
		pD++;
	}

	return *pD - sum;
}


DATA_TYPE computeLij(DATA_TYPE* pAal, DATA_TYPE* pD, DATA_TYPE* pL,
	int i, int j, int lowBandWidth) {

	DATA_TYPE sum = 0;
	DATA_TYPE* pLi = &pAal[i * lowBandWidth + lowBandWidth - i];
	DATA_TYPE* pLj = &pAal[j * lowBandWidth + lowBandWidth - j];
	//cout << pAal[i * lowBandWidth + lowBandWidth - i] << endl;

	for (int k = 1; k < j + 1; k++) {
		sum += (*pD) * (*pLi) * (*pLj);
		pD++;
		pLi++;
		pLj++;
	}
	//cout << (*pLi - sum) / *pD;
	return (*pLi - sum) / *pD;
}


DATA_TYPE _computeLij(DATA_TYPE* pLi, DATA_TYPE* pLj, DATA_TYPE* pD, int j){
	DATA_TYPE sum = 0;
	DATA_TYPE* limit = &pD[j];
	for (pD; pD < limit; pD++) {
		sum += (*pD) * (*pLi) * (*pLj);
		pLi++;
		pLj++;
	}
	return (*pLi - sum) / *pD;
}


DATA_TYPE _computeDi(DATA_TYPE* pLi, DATA_TYPE* pD,
	int i) { // i is the index of the calculated element of the D

	DATA_TYPE sum = 0;
	//DATA_TYPE* pLi = &pAal[i * lowBandWidth + lowBandWidth - i];
	DATA_TYPE Lij = 0; // temp variable to prevent repeated requests to the member

	for (int j = 1; j < i + 1; j++) {
		Lij = *pLi;
		sum += ((*pD) * Lij * Lij);
		pLi++;
		pD++;
	}

	return *pD - sum;
}


void SLAESolver::solveBandFormatLDLT(char* infoName, char* diName, char* aalName) {
	// ---- LOAD DATA ----
	DATA_TYPE dimAndLowBandWidth[2];
	memoryController->loadFile(infoName, 2, 1, dimAndLowBandWidth);
	
	int dimension = dimAndLowBandWidth[0];
	int lowBandWidth = dimAndLowBandWidth[1];

	int memoryForMatrixL = dimension * lowBandWidth;
	int memoryForDiagonal = dimension;
	int memoryForVectorX = dimension;
	int memoryForVectorB = dimension;
	int requiredMemorySize = memoryForMatrixL + memoryForDiagonal + 
		memoryForVectorX + memoryForVectorB;

	memoryController = new PseudoDynamicMemoryController;
	memoryController->initilizeMemory(requiredMemorySize);


	memoryController->loadFile(aalName, lowBandWidth, dimension);
	memoryController->loadFile(diName, dimension, 1);
	/*
	cout << "--- Aal ---" << endl;
	memoryController->printMemoryContent(0,
		dimension * lowBandWidth, lowBandWidth);
	cout << "--- A diagonal ---" << endl;
	memoryController->printMemoryContent(dimension * lowBandWidth, 
		dimension * lowBandWidth + dimension, dimension);
		*/
	// ---- ----

	// ---- FIND LDLT DECOMPOSITION ----
	DATA_TYPE* pHeap = memoryController->getMemoryPoolPointer();
	
	DATA_TYPE* pAal = pHeap;
	DATA_TYPE* pADiagonal = pHeap + dimension * lowBandWidth;

	DATA_TYPE* pL = pAal;
	DATA_TYPE* pD = pADiagonal;


	// d[0] is already calculated and equal to aDiagonal[0]

	DATA_TYPE* pLi = &pAal[1 * lowBandWidth + lowBandWidth - 1];
	DATA_TYPE* pLj = &pAal[0 * lowBandWidth + lowBandWidth - 0];

	//pLi = pAal;
	//pLj = pAal;

	for (int i = 1; i < lowBandWidth; i++) {
		for (int j = 0; j < i; j++) {
			pL[i * lowBandWidth + j + lowBandWidth - i] = _computeLij(pLi, pLj, pD, j);
			pLj++;
		}
		pD[i] = _computeDi(pLi, pD, i);
		pLi++;
	}

	//pLi = &pAal[lowBandWidth * lowBandWidth];
	//pLj += i - lowBandWidth;
	//pLj++;
	for (int i = lowBandWidth; i < dimension; i++) {
		for (int j = i - lowBandWidth; j < i; j++) {
			pL[i * lowBandWidth + j + lowBandWidth - i] = _computeLij(pLi, pLj, pD, j);
			pLj += i - lowBandWidth;
		}
		pD[i] = computeDi(pAal, pD, pL, i, lowBandWidth);
		pLi++;
	}


	
	/*for (int i = 1; i < lowBandWidth; i++) {
		for (int j = 0; j < i; j++) {
			pL[i * lowBandWidth + j + lowBandWidth - i] =
				computeLij(pAal, pD, pL, i, j, lowBandWidth);
		}
		pD[i] = computeDi(pAal, pD, pL, i, lowBandWidth);
	}

	for (int i = lowBandWidth; i < dimension; i++) {
		for (int j = i - lowBandWidth; j < i; j++) {
			pL[i * lowBandWidth + j + lowBandWidth - i] =
				computeLij(pAal, pD, pL, i, j, lowBandWidth);
		}
		pD[i] = computeDi(pAal, pD, pL, i, lowBandWidth);
	}*/
	

	cout << "--- l ---" << endl;
	memoryController->printMemoryContent(0,
		dimension * lowBandWidth, lowBandWidth);
	cout << "--- d ---" << endl;
	memoryController->printMemoryContent(dimension * lowBandWidth,
		dimension * lowBandWidth + dimension, dimension);
	
	// ---- ----
};


void SLAESolver::readLowHalfBandFormatMatrix(string AFileName, string bFileName) {
	
};





void build_band_matrix();
void calcLDLT();
void calcX();
void calcY();
void calcZ();

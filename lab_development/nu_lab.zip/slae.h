#pragma once
#include <string>
#include <fstream>
#include "pseudo_dynamic_memory_controller.h"
#include <iostream>
#include <fstream>


// SLAE notation: Ax = b
#define DATA_TYPE float
using namespace std;

class SLAESolver {
public:
	//SLAESolver(int requestedMemorySize);
	void solveBandFormatLDLT(char* infoName, char* diName, char* aalName);
	//~SLAE();
	//void readBandFormatMatrix();
	//void printBandFormatMatrix();
	//void printMatrix();
private:
	int dimension;
	PseudoDynamicMemoryController* memoryController;
	DATA_TYPE* A; // coefficientMatrix
	DATA_TYPE* x; // variableVector
	DATA_TYPE* b; // solutionVector

	void readLowHalfBandFormatMatrix(string AFileName, string bFileName);
};
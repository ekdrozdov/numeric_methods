#pragma once
#include <fstream>
#include <string>
#include <iostream>

using namespace std;

int run_all_tests(int testsTotal, string testReportFileName);
/*
*
* This is an implementation of the memory controller
* based on pseudo-dynamic memory paradigm.
*
* Author: E.K. Drozdov
*/


#include "pseudo_dynamic_memory_controller.h"

using namespace std;

PseudoDynamicMemoryController::PseudoDynamicMemoryController() {
	//memoryPoolPointer = (MEMORY_TYPE*)malloc(requiredMemorySize * sizeof(MEMORY_TYPE));
	shift = 0;
	//memoryPoolSizeInBytes = requiredMemorySize * sizeof(MEMORY_TYPE);
	memoryLeft = 0;
};



int PseudoDynamicMemoryController::initilizeMemory(int requiredMemorySize) {
	memoryPoolPointer = (MEMORY_TYPE*)malloc(requiredMemorySize * sizeof(MEMORY_TYPE));
	if (memoryPoolPointer == NULL) {
		cout << "initilizeMemory failed: cannot allocate memory" << endl;
		return -1;
	}
	memoryLeft += requiredMemorySize;
	return 0;
};


MEMORY_TYPE* PseudoDynamicMemoryController::holdMemory(int quantity) {
	if (quantity <= 0) {
		cout << "holdMemory faild: incorrect input" << endl;
		return NULL;
	}
	if (quantity > memoryLeft) {
		cout << "holdMemory faild: out of memory" << endl;
		return NULL;
	}
	int oldShift = shift;
	shift += quantity;
	memoryLeft -= quantity;
	return memoryPoolPointer + oldShift;
};


int PseudoDynamicMemoryController::loadFile(char* readingFileName, int columnsTotal,
	int stringsTotal, MEMORY_TYPE* memoryPointer) {
	//if (memoryPointer == memoryPoolPointer) {
	//	cout << "loadFile failed: memory pointer caanot refer to controllers memory";
	//	return -1;
	//}
	FILE* readingFile;
	errno_t err = fopen_s(&readingFile, readingFileName, "r");
	for (int i = 0; i < stringsTotal; i++) {
		for (int j = 0; j < columnsTotal; j++) {
			fscanf_s(readingFile, "%f", (memoryPointer + i * columnsTotal + j));
		}
	}
	fclose(readingFile);
	return 0;
}



int PseudoDynamicMemoryController::loadFile(char* readingFileName, int columnsTotal,
	int stringsTotal) {
	FILE* readingFile;
	errno_t err = fopen_s(&readingFile, readingFileName, "r");
	for (int i = 0; i < stringsTotal; i++) {
		for (int j = 0; j < columnsTotal; j++) {
			fscanf_s(readingFile, "%f", (memoryPoolPointer + i * columnsTotal + j + shift));
		}
	}
	shift += (columnsTotal * stringsTotal);
	fclose(readingFile);
	return 0;
}


int PseudoDynamicMemoryController::printMemoryContent(int startElementNumber,
	int endElementNumber, int stringLength) {
	int readingLength = endElementNumber - startElementNumber;
	int stirngsTotal = readingLength / stringLength;
	if (readingLength <= 0) {
		cout << "printMemoryContent failed: reading length <= 0" << endl;
		return -1;
	}
	for (int i = 0; i < stirngsTotal; i++) {
		for (int j = 0; j < stringLength; j++) {
			cout << *(memoryPoolPointer + i * stringLength + j + startElementNumber) 
				<< " ";
		}
		cout << endl;
	}
}


int PseudoDynamicMemoryController::printMemoryContent(MEMORY_TYPE* pointer, 
	int quantity, int stringLength) {
	for (int i = 0; i < (quantity / stringLength); i++) {
		for (int j = 0; j < stringLength; j++) {
			cout << *pointer << " ";
			pointer++;
		}
		cout << endl;
	}
	return 0;
}
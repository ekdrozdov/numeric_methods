#pragma once

typedef BandFormatLowHalf
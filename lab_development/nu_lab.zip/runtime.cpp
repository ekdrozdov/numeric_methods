/*
*
* This is runtime shell for numberical methods lab's development
* Author: Drozdov. E.K.
*/
//#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <Windows.h>
#include "tester.h"
#include "pseudo_dynamic_memory_controller.h"
#include "slae.h"

using namespace std;



void testTester() {
	int testsTotal = 2;
	string testReportFileName = "report.txt";
	run_all_tests(testsTotal, testReportFileName);
}



int main(int argc, char* argv[]) {
	SLAESolver slae;

	slae.solveBandFormatLDLT("info.txt", "di.txt", "aal.txt");
	
	system("pause");
	return 0;
}